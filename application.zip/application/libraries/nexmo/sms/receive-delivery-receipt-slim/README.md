### Usage

* Run `composer install`
* Start the web server `php -t . -S 127.0.0.1:3000`
